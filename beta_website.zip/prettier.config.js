module.exports = {
  printWidth: 120,
  singleQuote: true,
  semi: false,
  endOfLine: 'lf',
}
