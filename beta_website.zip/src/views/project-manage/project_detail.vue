<template>
<div style="height: 1000px;margin-top:20px; ">
<div  style="width: 90%;height: 250px;display:flex;background-color: white; margin:0 auto;">
  <div  style="width: 50%;height: 250px;display: inline-block;text-align:center;margin:0 auto;">
  <img src="@/assets/images/go_package.jpeg" style="width:150px;margin-top: 20%;">
  <br/>
  <a>标题</a>
  </div>
  <div style="
	height: 80%;
	width: 4px;
	margin: 0 auto;
	background-color: #e2e2e2;
    margin-top:2%
"></div>
  <div id="echarts168" style="width: 150%;height: 250px;"></div>
</div>
<div style="width: 90%;display:flex;background-color: white; margin:0 auto;margin-top:30px;bottom: 10px;">
  <n-collapse>
    <n-collapse-item title="评级说明"  >
      <div class = "FormDesc">
      <div class = "DescArea">
        <p class = "DescTitle">Bug评级说明</p>
        <div class = "DeasText">
          <p><span class = "N1 VSquare">致命</span>程序无法正常运行或程序无法跑通-无法正常启动、异常退出、crash、资源不足、死循环、崩溃或严重资源不足</p>
          <p><span class = "N2 VSquare">严重</span>核心功能无法完成、功能报错、数据错误等，但不会影响程序运行</p>
          <p><span class = "N3 VSquare">缺陷</span>一般功能性Bug，产品中的不符合产品需求或用户使用的缺陷</p>
          <p><span class = "N4 VSquare">瑕疵</span>操作不方便，布局不合理等一类的易用性相关的缺陷</p>
          <p><span class = "N5 VSquare">建议</span>对产品的改进优化型建议</p>
        </div>
      </div>
    </div>
    </n-collapse-item>
  </n-collapse>
</div>
<!-- <div  style="width: 90%;height: 250px;display:flex;background-color: white; margin:0 auto;margin-top:30px">
  <n-grid cols="4" item-responsive responsive="screen">
    
    <n-grid-item>
    <n-layout>
      <n-layout-header style="padding: 24px;">
      <div style="background-color: #1081de:height:100%"><h3>本次测试Bug总数</h3></div>
      </n-layout-header>
      <n-layout-content content-style="padding: 24px;">
        <div style="border:1px;margin-top:-10%;width:90%;height: 150px;background-color: #f8fcff;">
        
        </div>
      </n-layout-content>
    </n-layout>
    </n-grid-item>
    <n-grid-item span="0 m:1 l:3">
      <n-layout>
      <n-layout-header style="padding: 24px;">标题</n-layout-header>
      <n-layout-content content-style="padding: 24px;">
        内容
      </n-layout-content>
      <n-layout-content content-style="padding: 24px;">
        内容
      </n-layout-content>
    </n-layout>
    </n-grid-item>
  </n-grid>
</div> -->
<div class="card-frame">
  <n-card title="卡片" hoverable>
    卡片内容
  </n-card>
</div>
 <n-back-top :right="40" :bottom="160">
    <div
      style="
        width: 100px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        font-size: 14px;
      "
    >
      <a>回到顶部</a>
    </div>
  </n-back-top>
</div>
</template>
<script>
import { defineComponent, ref,onMounted,nextTick  } from "vue";
import { useMessage,NButton} from "naive-ui";
import * as echarts from 'echarts'

const props = {
    ewidth: {
        type: Number ,
        default: 100
    },
    eheight: {
        type: Number,
        default: 440
    }
}

export default defineComponent({
        props,
        setup (props, context) {
            console.log(context)
            let {ewidth: nwidth, eheight: nheight} = props
            const initCharts = () => {
                console.log('init charts')
                const option = {
                    xAxis: {
                        type: 'category',
                        data: ['致命', '严重', '缺陷', '瑕疵', '建议']
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [
                        {
                        data: [
                            {
                            value: 20,
                            itemStyle: {
                                color: '#ff6342'
                            }
                            }, 
                            {
                            value: 180,
                            itemStyle: {
                                color: '#ffd702'
                            }
                            }, {
                            value: 100,
                            itemStyle: {
                                color: '#7d6ece'
                            }
                            }, {
                            value: 50,
                            itemStyle: {
                                color: '#25b4fb'
                            }
                            }, {
                            value: 160,
                            itemStyle: {
                                color: '#00d492'
                            }
                            }],
                        type: 'bar',
                        itemStyle: {
                        normal: {
                        label: {
                            show: true, //开启显示

                            textStyle: {
                            //数值样式
                            color: 'black',
                            fontSize: 15
                            }
                        },
                        color: function (d) {
                            return (
                            '#' +
                            Math.floor(Math.random() * (256 * 256 * 256 - 1)).toString(16)
                            );
                        },
                        }
                        }
                        }
                    ]
                };

                const myChart = echarts.init(document.getElementById('echarts168'));
                myChart.setOption(option)
            
                window.onresize = () => {
                    myChart.resize()
                };

            }
            onMounted(() => {
                initCharts()
            })
            
            // 向外暴露初始化方法
            context.expose({
                initCharts
            })

            return {
                nwidth,
                nheight,
                show:true,
            }
        }

    })

</script>
<style scoped>
.FormDesc{
  background-color: white;
  min-width: 500px;
margin-bottom: 10px;
}
.DescArea{
  background-color:#FAFAFA;
  max-width:90%;
  height:120%;
  margin:auto;
  border:1px solid #ebebeb;

}
.DescTitle{
    text-align: center;
    font-size: 16px;
    line-height: 44px;
    margin-top: 7px;
}
.N1:before{
  background-color:#eb5a3c;
}
.N2:before{
  background-color:#FFC402;
}
.N3:before{
  background-color:#7264BC;
}
.N4:before{
  background-color:#22A4E5;
}
.N5:before{
  background-color:#00C185;
}
.VSquare:before{
  content: '';
  display: inline-block;
  width: 13px;
  height: 13px;
  margin-right: 10px;
  border-radius: 2px;
  position: relative;
  top: 1px;
}
.N1,.N2,.N3,.N4,.N5{
  padding-left: 120px;
  line-height:26px;
  margin-right: 48px;
}
.light-green {
  height: 108px;
  background-color: rgba(0, 128, 0, 0.12);
}
.green {
  height: 108px;
  background-color: rgba(0, 128, 0, 0.24);
}
.card-frame{
    width: 90%;height: 250px;display:flex;background-color: white; margin:0 auto;margin-top:30px
}
</style>