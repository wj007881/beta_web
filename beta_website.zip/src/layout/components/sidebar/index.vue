<script setup>
import SideLogo from './SideLogo.vue'
import SideMenu from './SideMenu.vue'
</script>

<template>
  <SideLogo />
  <SideMenu />
</template>
